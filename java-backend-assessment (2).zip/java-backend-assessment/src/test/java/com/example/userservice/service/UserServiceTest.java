package com.example.userservice.service;

import com.example.userservice.exception.UserNotFoundException;
import com.example.userservice.model.User;
import com.example.userservice.repository.InMemoryUserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class UserServiceTest {

    private UserService service;

    @BeforeEach
    void setup() {
        service = new UserServiceImpl(new InMemoryUserRepository());
    }

    @Test
    void testCreateAndGetUser() throws Exception {
        User u = new User(1L, "John", "john@mail.com");
        service.createUser(u);

        User result = service.getUser(1L);

        assertEquals("John", result.getName());
        assertEquals("john@mail.com", result.getEmail());
    }

    @Test
    void testUserNotFound() {
        assertThrows(UserNotFoundException.class,
                () -> service.getUser(999L));
    }

    @Test
    void testUpdateEmail() throws Exception {
        User u = new User(1L, "John", "old@mail.com");
        service.createUser(u);

        service.updateEmail(1L, "new@mail.com");

        assertEquals("new@mail.com", service.getUser(1L).getEmail());
    }

    @Test
    void testDeleteUser() throws Exception {
        service.createUser(new User(1L, "Test", "t@mail.com"));

        service.deleteUser(1L);

        assertThrows(UserNotFoundException.class,
                () -> service.getUser(1L));
    }
}
