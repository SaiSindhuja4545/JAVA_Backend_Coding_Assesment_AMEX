package com.example.userservice;

import com.example.userservice.repository.InMemoryUserRepository;
import com.example.userservice.service.UserService;
import com.example.userservice.service.UserServiceImpl;
import com.example.userservice.vertx.UserVerticle;
import io.vertx.core.Vertx;

public class Main {
    public static void main(String[] args) {
        Vertx vertx = Vertx.vertx();
        UserService service = new UserServiceImpl(new InMemoryUserRepository());
        vertx.deployVerticle(new UserVerticle(service));
    }
}
