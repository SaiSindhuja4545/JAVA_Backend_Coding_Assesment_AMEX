package com.example.userservice.vertx;

import com.example.userservice.exception.UserNotFoundException;
import com.example.userservice.model.User;
import com.example.userservice.service.UserService;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.BodyHandler;

public class UserVerticle extends AbstractVerticle {

    private final UserService service;

    public UserVerticle(UserService service) {
        this.service = service;
    }

    @Override
    public void start(Promise<Void> startPromise) {
        Router router = Router.router(vertx);
        router.route().handler(BodyHandler.create());

        router.post("/users").handler(ctx -> {
            JsonObject body = ctx.body().asJsonObject();   // <-- this is the key change
            if (body == null) {
                ctx.response().setStatusCode(400).end("Invalid JSON body");
                return;
            }

            Long id = body.getLong("id");
            String name = body.getString("name");
            String email = body.getString("email");

            if (id == null || name == null || email == null) {
                ctx.response().setStatusCode(400).end("Missing required fields");
                return;
            }

            service.createUser(new User(id, name, email));
            ctx.response().setStatusCode(201).end("User created");
        });


        router.get("/users/:id").handler(ctx -> {
            long id;
            try {
                id = Long.parseLong(ctx.pathParam("id"));
            } catch (NumberFormatException e) {
                ctx.response().setStatusCode(400).end("Invalid id");
                return;
            }

            try {
                User user = service.getUser(id);
                JsonObject json = new JsonObject()
                        .put("id", user.getId())
                        .put("name", user.getName())
                        .put("email", user.getEmail());
                ctx.response()
                        .putHeader("Content-Type", "application/json")
                        .end(json.encode());
            } catch (UserNotFoundException e) {
                ctx.response().setStatusCode(404).end(e.getMessage());
            }
        });

        router.put("/users/:id/email").handler(ctx -> {
            long id;
            try {
                id = Long.parseLong(ctx.pathParam("id"));
            } catch (NumberFormatException e) {
                ctx.response().setStatusCode(400).end("Invalid id");
                return;
            }

            JsonObject body = ctx.body().asJsonObject();
            if (body == null) {
                ctx.response().setStatusCode(400).end("Invalid JSON body");
                return;
            }

            String newEmail = body.getString("email");
            if (newEmail == null) {
                ctx.response().setStatusCode(400).end("Missing email");
                return;
            }

            try {
                service.updateEmail(id, newEmail);
                ctx.response().setStatusCode(200).end("Email updated");
            } catch (UserNotFoundException e) {
                ctx.response().setStatusCode(404).end(e.getMessage());
            }
        });


        router.delete("/users/:id").handler(ctx -> {
            long id;
            try {
                id = Long.parseLong(ctx.pathParam("id"));
            } catch (NumberFormatException e) {
                ctx.response().setStatusCode(400).end("Invalid id");
                return;
            }
            try {
                service.deleteUser(id);
                ctx.response().setStatusCode(200).end("User deleted");
            } catch (UserNotFoundException e) {
                ctx.response().setStatusCode(404).end(e.getMessage());
            }
        });

        vertx.createHttpServer()
                .requestHandler(router)
                .listen(8080)
                .onSuccess(server -> startPromise.complete())
                .onFailure(startPromise::fail);
    }
}
