package com.example.userservice.service;

import com.example.userservice.exception.UserNotFoundException;
import com.example.userservice.model.User;

public interface UserService {
    void createUser(User user);
    User getUser(long id) throws UserNotFoundException;
    void updateEmail(long id, String email) throws UserNotFoundException;
    void deleteUser(long id) throws UserNotFoundException;
}
