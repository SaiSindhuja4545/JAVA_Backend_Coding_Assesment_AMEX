package com.example.userservice;

import com.example.userservice.exception.UserNotFoundException;
import com.example.userservice.model.User;
import com.example.userservice.repository.InMemoryUserRepository;
import com.example.userservice.service.UserService;
import com.example.userservice.service.UserServiceImpl;

public class TestRunner {

    public static void main(String[] args) throws Exception {
        UserService service = new UserServiceImpl(new InMemoryUserRepository());

        int passed = 0;
        int failed = 0;

        // Test create & get
        try {
            User u = new User(1L, "John", "john@mail.com");
            service.createUser(u);
            User got = service.getUser(1L);
            assertEquals("John", got.getName(), "create/get name");
            assertEquals("john@mail.com", got.getEmail(), "create/get email");
            passed += 2;
        } catch (Throwable t) {
            t.printStackTrace();
            failed++;
        }

        // Test not found
        try {
            try {
                service.getUser(999L);
                fail("Expected UserNotFoundException");
            } catch (UserNotFoundException ex) {
                // expected
            }
            passed++;
        } catch (Throwable t) {
            t.printStackTrace();
            failed++;
        }

        // Test update email
        try {
            service.updateEmail(1L, "new@mail.com");
            User got = service.getUser(1L);
            assertEquals("new@mail.com", got.getEmail(), "update email");
            passed++;
        } catch (Throwable t) {
            t.printStackTrace();
            failed++;
        }

        // Test delete
        try {
            service.deleteUser(1L);
            try {
                service.getUser(1L);
                fail("Expected UserNotFoundException after delete");
            } catch (UserNotFoundException ex) {
                // expected
            }
            passed++;
        } catch (Throwable t) {
            t.printStackTrace();
            failed++;
        }

        System.out.println("Manual tests finished. Passed=" + passed + ", Failed=" + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void assertEquals(Object expected, Object actual, String message) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError("Assertion failed for " + message +
                    " expected=" + expected + " actual=" + actual);
        }
    }

    private static void fail(String message) {
        throw new AssertionError(message);
    }
}
