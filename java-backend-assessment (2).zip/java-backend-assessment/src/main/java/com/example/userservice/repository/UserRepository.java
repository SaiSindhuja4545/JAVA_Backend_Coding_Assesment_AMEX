package com.example.userservice.repository;

import com.example.userservice.model.User;

import java.util.Optional;

public interface UserRepository {

    void save(User user);

    Optional<User> findById(long id);

    void delete(long id);
}
