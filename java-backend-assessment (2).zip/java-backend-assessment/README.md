# Java Backend Coding Assessment

This project implements an in-memory user service with CRUD operations, Vert.x HTTP endpoints,
JUnit 5 tests, and a Docker configuration.

## Build

```bash
mvn clean package
```

## Run (locally)

```bash
java -jar target/java-backend-assessment-1.0-SNAPSHOT.jar
```

The service will start on port `8080`.

## Run Tests

```bash
mvn test
```

## Docker

Build the image:

```bash
docker build -t user-service .
```

Run the container:

```bash
docker run -p 8080:8080 user-service
```
